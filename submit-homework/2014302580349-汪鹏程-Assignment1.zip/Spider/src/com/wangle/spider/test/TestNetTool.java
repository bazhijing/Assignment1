package com.wangle.spider.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestNetTool {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetCookie() {
		fail("Not yet implemented");
	}

	@Test
	public void testLogin() {
		fail("Not yet implemented");
	}

	@Test
	public void testDownloadResource() {
		fail("Not yet implemented");
	}

	@Test
	public void testSaveToFileStringString() {
		fail("Not yet implemented");
	}

	@Test
	public void testSaveToFileStringBufferedImage() {
		fail("Not yet implemented");
	}

	@Test
	public void testDownloadImage() {
		fail("Not yet implemented");
	}

}
